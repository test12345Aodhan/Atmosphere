package com.application.atmosphereApp.Adapter;

import junit.framework.TestCase;

public class PostsAdapterTest extends TestCase {

}