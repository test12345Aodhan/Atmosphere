package com.application.atmosphereApp.Models;


public class Location {

private Long Latitude;
private Long Longitude;
private String postcode;
private String City;
private String streetAdd;

public Location(){

}

    public Location(Long latitude, Long longitude, String postcode, String city, String streetAdd) {
        Latitude = latitude;
        Longitude = longitude;
        this.postcode = postcode;
        City = city;
        this.streetAdd = streetAdd;
    }

    public Long getLatitude() {
        return Latitude;
    }

    public void setLatitude(Long latitude) {
        Latitude = latitude;
    }

    public Long getLongitude() {
        return Longitude;
    }

    public void setLongitude(Long longitude) {
        Longitude = longitude;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getStreetAdd() {
        return streetAdd;
    }

    public void setStreetAdd(String streetAdd) {
        this.streetAdd = streetAdd;
    }
}
