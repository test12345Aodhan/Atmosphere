package com.application.atmosphereApp.Fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.application.atmosphereApp.Adapter.PostsAdapter;
import com.application.atmosphereApp.Models.Posts;

import com.application.atmosphereApp.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class PostsDetails extends Fragment {

String postID;
private List<Posts> postList;
private RecyclerView recyclerView;
private PostsAdapter postsAdapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View v = inflater.inflate(R.layout.fragment_posts_details,container,false);


       postID = getContext().getSharedPreferences("Preferences", Context.MODE_PRIVATE).getString("postID","none");


        recyclerView = v.findViewById(R.id.recycle_view_postdetails);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(manager);


        postList = new ArrayList<>();
        postsAdapter = new PostsAdapter(getContext(),postList);
        recyclerView.setAdapter(postsAdapter);


       readIn();

       return  v;
    }


    public void readIn(){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Posts").child(postID);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot snapshot) {
                postList.clear();
                Posts posts = snapshot.getValue(Posts.class);
                postList.add(posts);

                postsAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



}