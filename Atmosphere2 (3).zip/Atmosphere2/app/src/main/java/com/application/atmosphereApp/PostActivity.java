package com.application.atmosphereApp;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;

import java.util.HashMap;
import java.util.Locale;

//add try and catches
public class PostActivity extends AppCompatActivity {

    String myURL = "";
   private Uri imageUri;
    private StorageTask upload;
      private  StorageReference reference;

    //class vars
   private ImageView exit, add_img;
   private EditText img_def;
   private TextView post_now;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

//connect java vars to xml id
        exit = findViewById(R.id.exit);
        add_img = findViewById(R.id.add_img);
        post_now = findViewById(R.id.post_now);
        img_def = findViewById(R.id.img_def);
        reference = FirebaseStorage.getInstance().getReference("posts");

        //ability to upload image
        //if post now button is hit then upload the image
        post_now.setOnClickListener(view -> uploadPost());
        //if exit is hit then return to main activity page
        exit.setOnClickListener(view -> {
            startActivity(new Intent(PostActivity.this, MainActivity.class));
            finish();
        });

        //ability to crop picture
        //to user liking
        CropImage.activity().setAspectRatio(1, 1)
                .start(PostActivity.this);




    }

    public String fileMimeType(Uri uri) {

        String mimetype = null;
        if (ContentResolver.SCHEME_CONTENT.equals(uri.getScheme())) {
            ContentResolver contentResolver = getApplicationContext().getContentResolver();
            mimetype = contentResolver.getType(uri);
        } else {
            String file = MimeTypeMap.getFileExtensionFromUrl(uri.toString());
            mimetype = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.toLowerCase());
        }
        return mimetype;
    }
    /**
     * method to allow the user to upload an image to app
     */
    private void uploadPost() {
        //add progress bar with message
        ProgressDialog progressD = new ProgressDialog(this);
        progressD.setMessage("Uploading your atmosphere");
        progressD.show();

        //if there is an image
        //or if image is not none
        if (imageUri != null) {

            //image ref equals the system time plus extension name
            StorageReference ref = reference.child(System.currentTimeMillis() +"." + fileMimeType(imageUri));

            //then upload the Image to the referenced database file
            upload = ref.putFile(imageUri);
            upload.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                ;

                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }
                        return ref.getDownloadUrl();
                    }

            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    Uri forDownload = (Uri) task.getResult();


                    myURL = forDownload.toString().trim();
                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Posts");
                    String postID = databaseReference.push().getKey();

                    HashMap<String, Object> map = new HashMap<>();

                    map.put("postID", postID);
                    map.put("postDescription", img_def.getText().toString());
                    map.put("imageURL", myURL);
                    map.put("postedBy", FirebaseAuth.getInstance().getCurrentUser().getUid());

                    databaseReference.child(postID).setValue(map);

                    progressD.dismiss();
                    startActivity(new Intent(PostActivity.this, MainActivity.class));
                    finish();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });

        }


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
        CropImage.ActivityResult res = CropImage.getActivityResult(data);
        imageUri = res.getUri();
            add_img.setImageURI(imageUri);
        } else {
            Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
         startActivity(new Intent( PostActivity.this, MainActivity.class));
        finish();

        }
    }


}