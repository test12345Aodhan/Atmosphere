package com.application.atmosphereApp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class Options extends AppCompatActivity {

    TextView log_out;

    //add try and catches

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        Toolbar toolbar= findViewById(R.id.tool_bar_options);
        log_out = findViewById(R.id.log_Out);


        getSupportActionBar().setTitle("Options");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(view -> finish());


        log_out.setOnClickListener(view -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(Options.this, StartActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
        });


    }




}