package com.application.atmosphereApp.CustomerFrags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.application.atmosphereApp.Adapter.VenueAdapter;
import com.application.atmosphereApp.Models.Venues;
import com.application.atmosphereApp.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 *
 * create an instance of this fragment.
 */
public class Search extends Fragment {

    private RecyclerView recyclerView;
    private List<Venues> aVenues;
    private VenueAdapter venueAdapter;

    EditText search_bar_Text;


        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {

            View v = inflater.inflate(R.layout.fragment_search, container, false);


            recyclerView = v.findViewById(R.id.recycle_view_search);
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

            search_bar_Text = v.findViewById(R.id.search_bar_text);

            aVenues = new ArrayList<>();

            venueAdapter = new VenueAdapter(getContext(),aVenues, true);

            recyclerView.setAdapter(venueAdapter);


            readVenues();
            search_bar_Text.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    searchVenues(charSequence.toString().toLowerCase());
                }

                @Override
                public void afterTextChanged(Editable editable) {

                }
            });

            return v;
        }


        //method to search venues
        public void searchVenues(String s){
            //query firebase data

            Query q = FirebaseDatabase.getInstance().getReference("Venues")   //of type Venues
                    .orderByChild("venueName")
                    .startAt(s).endAt(s+ "\uff8ff");

            q.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    aVenues.clear();
                    for (DataSnapshot snap : snapshot.getChildren()){
                        Venues venue = snap.getValue((Venues.class));
                        aVenues.add(venue);

                    }
                    venueAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });




        }

        private void readVenues(){
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Venues");

            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(search_bar_Text.getText().toString().equalsIgnoreCase("")){
                        aVenues.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren() ){
                            Venues venue = dataSnapshot.getValue(Venues.class);
                            aVenues.add(venue);
                        }
                        venueAdapter.notifyDataSetChanged();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
    }
