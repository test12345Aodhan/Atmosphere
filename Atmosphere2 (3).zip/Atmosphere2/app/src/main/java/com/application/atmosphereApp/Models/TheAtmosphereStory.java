package com.application.atmosphereApp.Models;

public class TheAtmosphereStory {

    private String imageURL;
    private long timeStart;
    private long timeEnd;
    private String storyID;
    private String VenueID;

    public TheAtmosphereStory(){

    }

    public TheAtmosphereStory(String imageURL, long timeStart, long timeEnd, String storyID, String venueID) {
        this.imageURL = imageURL;
        this.timeStart = timeStart;
        this.timeEnd = timeEnd;
        this.storyID = storyID;
        this.VenueID = venueID;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public long getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(long timeStart) {
        this.timeStart = timeStart;
    }

    public long getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(long timeEnd) {
        this.timeEnd = timeEnd;
    }

    public String getStoryID() {
        return storyID;
    }

    public void setStoryID(String storyID) {
        this.storyID = storyID;
    }

    public String getVenueID() {
        return VenueID;
    }

    public void setVenueID(String venueID) {
        VenueID = venueID;
    }


}
