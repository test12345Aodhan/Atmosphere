package com.application.atmosphereApp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.application.atmosphereApp.Fragments.Add;
import com.application.atmosphereApp.Fragments.Home;
import com.application.atmosphereApp.Fragments.NotificationsFrag;
import com.application.atmosphereApp.Fragments.Profile;
import com.application.atmosphereApp.Fragments.Search;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;


//add try catches and rework code

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    Fragment selectedFrag = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bundle intent = getIntent().getExtras();
        if (intent != null) {
            String postedBy = intent.getString("postedBy");


         SharedPreferences.Editor editor = getSharedPreferences("PREFS", MODE_PRIVATE).edit();
         editor.putString("profileID", postedBy);
         editor.apply();

            getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment, new Profile()).commit();

        } else {

            getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment, new Home()).commit();

        }

        bottomNavigationView = findViewById(R.id.bottom_nav);



        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.home_logo:
                    selectedFrag = new Home();
                    break;
                case R.id.search_logo:
                    selectedFrag = new Search();
                    break;
                case R.id.profile_nav:
                    SharedPreferences.Editor edit = getSharedPreferences("Preferences", Context.MODE_PRIVATE).edit();
                    edit.putString("profileID", FirebaseAuth.getInstance().getCurrentUser().getUid());
                    edit.apply();
                    selectedFrag = new Profile();
                    break;
                case R.id.add:
                    selectedFrag = new Add();
                    startActivity(new Intent(MainActivity.this, PostActivity.class));
                    break;
                case R.id.notifications:
                    selectedFrag = new NotificationsFrag();
                    break;

            }
            if (selectedFrag != null) {
                getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment, selectedFrag).commit();
            }
            return true;

        });


    }
}