package com.application.atmosphereApp.Models;

public class Notifications {


    private String userID;
    private String text;
    private String postID;
    private boolean isPosted;

    public Notifications(){

    }

    public Notifications(String userID, String text, String postID, boolean isPosted) {
        super();
        this.userID = userID;
        this.text = text;
        this.postID = postID;
        this.isPosted = isPosted;
    }


    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getPostID() {
        return postID;
    }

    public void setPostID(String postID) {
        this.postID = postID;
    }

    public boolean isPosted() {
        return isPosted;
    }

    public void setPosted(boolean posted) {
        isPosted = posted;
    }
}
