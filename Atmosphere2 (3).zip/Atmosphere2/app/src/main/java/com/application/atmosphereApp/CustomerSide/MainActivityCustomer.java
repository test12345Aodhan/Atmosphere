package com.application.atmosphereApp.CustomerSide;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import com.application.atmosphereApp.Fragments.Home;

import com.application.atmosphereApp.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivityCustomer extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    Fragment selectedFrag = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_customer);


        bottomNavigationView = findViewById(R.id.bottom_nav_customer);


        bottomNavigationView.setOnItemSelectedListener(navSelectedItemListener);

        getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment,new Home()).commit();

    }

    private NavigationBarView.OnItemSelectedListener navSelectedItemListener = menuItem -> {
        switch (menuItem.getItemId()) {
            case R.id.home_logo:
                selectedFrag = new com.application.atmosphereApp.CustomerFrags.Home();
                break;
            case R.id.notifications:
                selectedFrag = new com.application.atmosphereApp.CustomerFrags.Notifications();
                break;
            case R.id.search_logo:
                selectedFrag = new com.application.atmosphereApp.CustomerFrags.Search();
                break;


        }
        if(selectedFrag !=null){
            getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment,selectedFrag).commit();
        }
        return true;


    };

}