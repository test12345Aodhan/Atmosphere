package com.application.atmosphereApp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.theartofdev.edmodo.cropper.CropImage;

import java.util.HashMap;


//change this class to adding video url

public class AddStory extends AppCompatActivity {

    private Uri imageURl;
    String myURL = "";
    private StorageTask storageTask;
    StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_story);


        storageReference = FirebaseStorage.getInstance().getReference("story");

        CropImage.activity().setAspectRatio(8, 15).start(AddStory.this);


    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));

    }

    private void postStory() {
        ProgressDialog progress = new ProgressDialog(this);
        progress.setMessage("Posting");
        progress.show();

        if (imageURl != null) {

            StorageReference imageRef = storageReference.child(System.currentTimeMillis() + "." + getFileExtension(imageURl).trim());
            storageTask = imageRef.putFile(imageURl);
            storageTask.continueWithTask(new Continuation() {
                @Override
                public Object then(@NonNull Task task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }
                    return imageRef.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri download = task.getResult();
                        myURL = download.toString();

                        String id = FirebaseAuth.getInstance().getCurrentUser().getUid();

                        DatabaseReference ref2 = FirebaseDatabase.getInstance().getReference("Story").child(id);

                        String storyID = ref2.push().getKey();
                        long timeend = System.currentTimeMillis() + 89000000;

                        HashMap<String, Object> hashMap = new HashMap<>();
                        hashMap.put("imageURL", myURL);
                        hashMap.put("timestart", ServerValue.TIMESTAMP);
                        hashMap.put("timeend", timeend);
                        hashMap.put("storyID", storyID);
                        hashMap.put("venueID", id);

                        ref2.child(storyID).setValue(hashMap);
                        progress.dismiss();
                        finish();

                    } else {
                        Toast.makeText(AddStory.this, "Story Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(AddStory.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }

            });

        } else {
            Toast.makeText(AddStory.this, "No image Selected", Toast.LENGTH_SHORT).show();
        }
            }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if ((requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK)){
            CropImage.ActivityResult res = CropImage.getActivityResult(data);
            imageURl = res.getUri();


           postStory();
        } else {
            Toast.makeText(this, "Something went wrong, please try again ", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(AddStory.this, MainActivity.class));

        }
    }

}