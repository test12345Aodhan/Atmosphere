package com.application.atmosphereApp.CustomerFrags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.application.atmosphereApp.Adapter.PostsAdapter;
import com.application.atmosphereApp.Adapter.StoryAdapter;
import com.application.atmosphereApp.Models.Posts;
import com.application.atmosphereApp.Models.TheAtmosphereStory;
import com.application.atmosphereApp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.

 * create an instance of this fragment.
 */
public class Home extends Fragment {

private ProgressBar progressBar;
private RecyclerView recyclerView;
private List<Posts> postsList;
private List<String> followingList;
private PostsAdapter postsAdapter;
private RecyclerView recyclerView_story;
private StoryAdapter storyAdapter;
private List<TheAtmosphereStory> storiesList;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        recyclerView = view.findViewById(R.id.recycle_view);
        recyclerView.setHasFixedSize(true);
        progressBar = view.findViewById(R.id.progress_bar);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        postsList = new ArrayList<>();
        postsAdapter = new PostsAdapter((getContext()), postsList);
        recyclerView.setAdapter(postsAdapter);
        checkIfFollowing();

        recyclerView_story = view.findViewById(R.id.recycle_view_stories);
        recyclerView_story.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView_story.setLayoutManager(linearLayoutManager1);
        storiesList = new ArrayList<>();
        storyAdapter = new StoryAdapter(getContext(), storiesList);
        recyclerView_story.setAdapter(storyAdapter);


        return view;
    }

    private void readPostedPosts() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Posts");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                postsList.clear();
                //loop through database and add the posts to the page
                //based on if user is following venue
                for (DataSnapshot dSnapshot : snapshot.getChildren()) {
                    Posts posted = dSnapshot.getValue(Posts.class);
                    for (String id : followingList) {
                        if (posted.getPostedBy().equals(id)) {
                            postsList.add(posted);
                        }
                    }
                }
                postsAdapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void checkIfFollowing() {
        followingList = new ArrayList<>();


        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Follow")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("following");


        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                followingList.clear();
                for (DataSnapshot dSnapshot : snapshot.getChildren()) {
                    followingList.add(dSnapshot.getKey());
                }
                readPostedPosts();
                readInStory();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    private void readInStory () {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Story");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                long time = System.currentTimeMillis();
                storiesList.clear();
                storiesList.add(new TheAtmosphereStory("", 0, 0, "", FirebaseAuth.getInstance().getCurrentUser().getUid()));
                for (String id : followingList) {
                    int count = 0;
                    TheAtmosphereStory story = null;
                    for (DataSnapshot snap : snapshot.child(id).getChildren()) {
                        story = snap.getValue(TheAtmosphereStory.class);
                        if (time > story.getTimeStart() && time < story.getTimeEnd()) {
                            count++;
                        }
                    }
                    if (count > 0) {
                        storiesList.add(story);
                    }
                }
                storyAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });
    }
}