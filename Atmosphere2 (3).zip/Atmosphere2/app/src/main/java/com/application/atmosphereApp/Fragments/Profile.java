package com.application.atmosphereApp.Fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.application.atmosphereApp.Adapter.MyPhotosAdapter;
import com.application.atmosphereApp.EditProfile;
import com.application.atmosphereApp.FollowersActivity;
import com.application.atmosphereApp.Models.Posts;
import com.application.atmosphereApp.Models.Venues;
import com.application.atmosphereApp.Options;

import com.application.atmosphereApp.R;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * A simple {@link Fragment} subclass.
 *
 * create an instance of this fragment.
 */
public class Profile extends Fragment {

    CircleImageView profile_img;
    ImageButton options;

    TextView username, location, venueName, following, followers, posts;
    Button profile_edit;
    TextView tag1, tag2, tag3, tag4, tag5;

    private List<String> mySaves;
    FirebaseUser fUser;
    String profileID;

    private RecyclerView recyclerView, recyclerView_saved;
    private MyPhotosAdapter photosAdapter, photosAdapterSaves;
    private List<Posts> postsList, postsListSaves;

    private ImageButton myPhotos, savedPhotos;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_profile, container, false);


        fUser = FirebaseAuth.getInstance().getCurrentUser();
      SharedPreferences preferences = getContext().getSharedPreferences("Preferences", Context.MODE_PRIVATE);
        profileID = preferences.getString("profileID", "none");

        profile_img = v.findViewById(R.id.profile_img);
        options = v.findViewById(R.id.profile_options);
        posts = v.findViewById(R.id.posts);
        followers =v.findViewById(R.id.followers_profile);
        following = v.findViewById(R.id.following);
        venueName = v.findViewById(R.id.venueName_profile);
        location = v.findViewById(R.id.location);
        username = v.findViewById(R.id.profileName);
        profile_edit = v.findViewById(R.id.profile_editor);
        myPhotos = v.findViewById(R.id.my_pics);
        savedPhotos = v.findViewById(R.id.saved_pics);
        tag1 = v.findViewById(R.id.venue_Tags);
        tag2 = v.findViewById(R.id.venue_Tags2);
        tag3 = v.findViewById(R.id.venue_Tags3);
        tag4 = v.findViewById(R.id.venue_Tags4);
        tag5 = v.findViewById(R.id.venue_Tags5);


        recyclerView = v.findViewById(R.id.recycle_view);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layout3 = new GridLayoutManager(getActivity(),3);
        recyclerView.setLayoutManager(layout3);
        postsList = new ArrayList<>();
        photosAdapter = new MyPhotosAdapter(getContext(),postsList);
        recyclerView.setAdapter(photosAdapter);



        recyclerView_saved = v.findViewById(R.id.recycle_saved_PICS);
        LinearLayoutManager layout2 = new GridLayoutManager(getContext(),3);
        recyclerView_saved.setLayoutManager(layout2);
        postsListSaves = new ArrayList<>();
        photosAdapterSaves = new MyPhotosAdapter(getContext(),postsListSaves);
        recyclerView_saved.setAdapter(photosAdapterSaves);

            recyclerView.setVisibility(View.VISIBLE);
            recyclerView_saved.setVisibility(View.GONE);

            venueInfo();
            getFollowersForPage();
            getNumberOfPosts();
            profilePhotos();
            savedPhotos();

            if(profileID.equals(fUser.getUid())){
                profile_edit.setText("Edit Profile");
            } else {
                checkIfFollow();
                savedPhotos.setVisibility(View.GONE);
            }


            profile_edit.setOnClickListener(view -> {
                String button = profile_edit.getText().toString();
                   if(button.equals("Edit Profile")) {
                       startActivity(new Intent(getContext(), EditProfile.class));
                   } else if (button.equals("follow")) {
                       FirebaseDatabase.getInstance().getReference().child("Follow").child(fUser.getUid()).child("following").child(profileID).setValue(true);
                       FirebaseDatabase.getInstance().getReference().child("Follow").child(fUser.getUid()).child("followers").child(profileID).setValue(true);
                       addNotifications();
                   }  else if (button.equals("following")) {
                        FirebaseDatabase.getInstance().getReference().child("Follow").child(fUser.getUid()).child("following").child(profileID).removeValue();
                        FirebaseDatabase.getInstance().getReference().child("Follow").child(fUser.getUid()).child("followers").child(profileID).removeValue();

                }
            });

            options.setOnClickListener(view -> startActivity(new Intent(getContext(),Options.class)));

            myPhotos.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(getContext(), "this has been clicked", Toast.LENGTH_SHORT).show();
                    recyclerView.setVisibility(View.VISIBLE);
                    recyclerView_saved.setVisibility(View.GONE);
                }
            });

        savedPhotos.setOnClickListener(view -> {
            recyclerView.setVisibility(View.GONE);
            recyclerView_saved.setVisibility(View.VISIBLE);
        });

        followers.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(),FollowersActivity.class);
            intent.putExtra("id",profileID);
            intent.putExtra("title","followers");
            startActivity(intent);
        });

        following.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(),FollowersActivity.class);
            intent.putExtra("id",profileID);
            intent.putExtra("title","following");
            startActivity(intent);
        });


    return v;

    }


    private void addNotifications(){
      DatabaseReference query =  FirebaseDatabase.getInstance().getReference("Notifications").child(profileID);

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("userID", fUser.getUid());
        hashMap.put("text", "started following you");
        hashMap.put("postID", "");
        hashMap.put("isPosted", false);

        query.push().setValue(hashMap);

    }

    private void venueInfo(){
        FirebaseDatabase.getInstance().getReference("Venues").child(profileID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
            if(getContext() == null){
                return;
            }
                Venues venue = snapshot.getValue(Venues.class);
                venueName.setText(venue.getVenueName());
                location.setText(venue.getEmailAdd());
                tag1.setText(venue.getTag1());
                tag2.setText(venue.getTag2());
                tag3.setText(venue.getTag3());
                tag4.setText(venue.getTag4());
                tag5.setText(venue.getTag5());
                    if(venue.getImageURL().equals("default")){
                        profile_img.setImageResource(R.mipmap.ic_launcher);
                    } else {
                        if (getContext()!=null)
                            Glide.with(getContext()).load(venue.getImageURL()).into(profile_img);
                    }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void checkIfFollow(){
        FirebaseDatabase.getInstance().getReference().child("Follow").child(fUser.getUid()).child("following").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (!snapshot.child(profileID).exists()){
                    profile_edit.setText("follow");
                } else {
                    profile_edit.setText("following");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void getFollowersForPage(){

       DatabaseReference query1 = FirebaseDatabase.getInstance().getReference("Follow").child(profileID).child("followers");
               query1.addValueEventListener(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                followers.setText(" "+snapshot.getChildrenCount());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
               DatabaseReference query2 = FirebaseDatabase.getInstance().getReference("Follow").child(profileID).child("following");
                query2.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                    following.setText(" "+snapshot.getChildrenCount());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
    private void getNumberOfPosts(){
      DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Posts");
      ref.addValueEventListener(new ValueEventListener() {
          @Override
          public void onDataChange(@NonNull DataSnapshot snapshot) {
              int i = 0;
              for(DataSnapshot reference : snapshot.getChildren()){
                  Posts post = reference.getValue(Posts.class);

                          if(post.getPostedBy().equals(profileID)){
                              i++;
                          }
              }
              posts.setText(" "+i);
          }

          @Override
          public void onCancelled(@NonNull DatabaseError error) {

          }
      });
    }

    private void profilePhotos(){
        DatabaseReference reference =  FirebaseDatabase.getInstance().getReference("Posts");
        reference.addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snappy : snapshot.getChildren()){
                    Posts posts = snappy.getValue(Posts.class);
                    if(posts.getPostedBy().equals(profileID)){
                        postsList.add(posts);
                    }
                }

                Collections.reverse((postsList));
                photosAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    private void savedPhotos(){
        mySaves = new ArrayList<>();
        FirebaseDatabase.getInstance().getReference("Saves").child(fUser.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot shot : snapshot.getChildren()){
                    mySaves.add(shot.getKey());
                }
                readSavedPics();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    private void readSavedPics(){
        FirebaseDatabase.getInstance().getReference("Posts").addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                postsListSaves.clear();

                for (DataSnapshot snapshot1 :snapshot.getChildren()){
                    Posts posts = snapshot1.getValue(Posts.class);
                    for (String iD : mySaves){
                        assert posts != null;
                        if (posts.getPostID().equals(iD)){
                            postsListSaves.add(posts);
                        }
                        }
                    }
                        photosAdapterSaves.notifyDataSetChanged();

                }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}