package com.application.atmosphereApp.CustomerSide;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.application.atmosphereApp.Login;
import com.application.atmosphereApp.R;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

/**
 * class to register the customer details on firebase
 * includes ability to login and register user from facebook and gmail
 * extends activity layout
 */
public class RegisterAsCustomer extends AppCompatActivity {

    FirebaseAuth mAuth;
    DatabaseReference ref;
    ProgressDialog progressD;

    EditText username, email, password, password_confirm;
    Button register;
    TextView login_acc_already, userTxt;

    //class vars for facebook sign in usage
    private CallbackManager callbackManager;
    private LoginButton loginButton_FB;
    private static final String TAG = "Facebook Authentication";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_as_customer);


        username = findViewById(R.id.username);
        email = findViewById(R.id.emailAddress);
        password = findViewById(R.id.password);
        password_confirm = findViewById(R.id.passwordConfirm);
        register = findViewById(R.id.registerBTN);
        login_acc_already = findViewById(R.id.login_acc_already);

        mAuth = FirebaseAuth.getInstance();
        FacebookSdk.sdkInitialize(getApplicationContext());
        loginButton_FB = findViewById(R.id.login_button_FB);
        callbackManager = CallbackManager.Factory.create();
        loginButton_FB.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.d(TAG,"On Success"+loginResult);
                facebookHandler(loginResult.getAccessToken());
            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {

            }
        });


        //if user has registered previously then direct to login page
        login_acc_already.setOnClickListener(view -> startActivity(new Intent(RegisterAsCustomer.this, Login.class)));


        //if register button is hit then bring up progress dialog bar
        register.setOnClickListener(view -> {
            progressD = new ProgressDialog(RegisterAsCustomer.this);
            progressD.setMessage("Please wait");
            progressD.show();


//get user inputs to string
            String username_reg = username.getText().toString();
            String email_reg = email.getText().toString();
            String password_reg = password.getText().toString();
            String password_dup_reg = password_confirm.getText().toString();


            //make sure they have filled in all fields and password matches
            if (TextUtils.isEmpty(username_reg)
                    || TextUtils.isEmpty(email_reg) || TextUtils.isEmpty(password_reg) || TextUtils.isEmpty(password_dup_reg)){
                Toast.makeText(RegisterAsCustomer.this, "All fields required", Toast.LENGTH_SHORT).show();
            } else if (!password_dup_reg.matches(password_reg)){
                password_confirm.setError("password does not match");
                password_confirm.requestFocus();
            } else if(password_reg.length()<6) {
                password.setError("password length at least 6 characters");
                password.requestFocus();

            } else {
                //if all fields are filled in then try register the account with username, email and password

                registerCustomer(username_reg,email_reg,password_reg);
            }
        });
    }

    /**
     * method to register the customer to the firebase database
     * @param username
     * @param email
     * @param password
     */
    private void registerCustomer(final String username, final String email, String password){
        //creates user with email and password
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(RegisterAsCustomer.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        //on complete then get the current user and current uid
                        if (task.isSuccessful()){
                            FirebaseUser firebaseUser = mAuth.getCurrentUser();
                            String userID = firebaseUser.getUid();

                            //reference the database
                            ref = FirebaseDatabase.getInstance().getReference().child("Users").child(userID);
                            //map the data and using the string vars put into firebase
                            HashMap<String, Object> hashMap = new HashMap<>();
                            hashMap.put("id",userID);
                            hashMap.put("username", username.toLowerCase());
                            hashMap.put("email", email);
                            hashMap.put("imageURL", "https://firebasestorage.googleapis.com/v0/b/atmosphereapp-a421c.appspot.com/o/ic_no_image.png?alt=media&token=d81883bc-36b8-41a1-8103-6e23b9fc3a56");

                            ref.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    //if task is successful then dismiss the dialog bar and switch
                                    if (task.isSuccessful()){
                                        progressD.dismiss();
                                        //display message to user to say they have registered
                                        Toast.makeText(RegisterAsCustomer.this, "You are now registered", Toast.LENGTH_SHORT).show();
                                        //redirect user to login page
                                        Intent intent = new Intent(RegisterAsCustomer.this, Login.class);

                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                        startActivity(new Intent(RegisterAsCustomer.this,Login.class));
                                    }
                                }
                            });

                        } else {
                            //message to show reg has failed
                            progressD.dismiss();
                            Toast.makeText(RegisterAsCustomer.this, "Registration Failed, Try different email or password", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    /**
     * method to handle facebook login
     * @param token
     */
    private void facebookHandler(AccessToken token){
        Log.d(TAG, "handleToken"+token);
        //get user credentials from facebook

        AuthCredential cred = FacebookAuthProvider.getCredential(token.getToken());
        mAuth.signInWithCredential(cred).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        progressD.dismiss();
                        Toast.makeText(RegisterAsCustomer.this, "Sign in Successfull", Toast.LENGTH_SHORT).show();
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null){
                            user.getDisplayName().toString();
                           String image =  user.getPhotoUrl().toString();
                           String userID = user.getUid();
                            ref = FirebaseDatabase.getInstance().getReference().child("Users").child(userID);

                            HashMap<String, Object> hashMap = new HashMap<>();
                            hashMap.put("id",userID);
                            hashMap.put("username", user.getDisplayName().toString());
                            hashMap.put("email", email);
                            hashMap.put("imageURL", image);

                        }


                    } else {
                     //   Toast.makeText(, "", Toast.LENGTH_SHORT).show();
                    }
            }
        });
    }




}
