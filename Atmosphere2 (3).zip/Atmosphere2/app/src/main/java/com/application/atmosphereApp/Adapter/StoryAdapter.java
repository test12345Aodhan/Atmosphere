package com.application.atmosphereApp.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.application.atmosphereApp.AddStory;
import com.application.atmosphereApp.Models.TheAtmosphereStory;
import com.application.atmosphereApp.Models.Venues;
import com.application.atmosphereApp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.ViewHolder> {

    private Context context;
    private List<TheAtmosphereStory> story;

    public StoryAdapter(Context context, List<TheAtmosphereStory> story) {
        this.context = context;
        this.story = story;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {

        if (i == 0) {
            View v = LayoutInflater.from(context).inflate(R.layout.add_atmosphere_story, parent, false);

            return new StoryAdapter.ViewHolder(v);
        } else {
            View v = LayoutInflater.from(context).inflate(R.layout.stories_items, parent, false);

            return new StoryAdapter.ViewHolder(v);


        }

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TheAtmosphereStory stories = story.get(position);

        venueInfo(holder,stories.getVenueID(), position);

        if ((holder.getAdapterPosition() !=0)){
            venueStorySeen(holder, stories.getVenueID());
        }

        if(holder.getAdapterPosition() == 0 ){
            myVenueStory(holder.addStory_text,holder.story_add,false);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(holder.getAdapterPosition() == 0 ){
                    myVenueStory(holder.addStory_text,holder.story_add,true);
                }
                else {
                    //TODO GO TO STORY
                }
            }
        });
    }



    @Override
    public int getItemCount() {
        return story.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView photo_story, story_add, story_seen;
        public TextView story_venue_name, addStory_text;

        public ViewHolder(@NonNull View v) {
            super(v);

            photo_story = v.findViewById(R.id.story_photo);
            story_add = v.findViewById(R.id.add_story);
            story_seen = v.findViewById(R.id.atmosphere_story_seen);
            story_venue_name = v.findViewById(R.id.story_venueName);
            addStory_text = v.findViewById(R.id.add_text_story);

        }


    }


    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return 0;
        }
        return 1;
    }

    private void venueInfo(ViewHolder vHolder, String venueID, int i){

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Venues").child(venueID);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Venues venue = snapshot.getValue(Venues.class);
           //    Glide.with(context).load(venue.getPostImage()).into(vHolder.photo_story);
//               vHolder.story_venue_name.setText(venue.getVenueName());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void myVenueStory(final TextView textView,ImageView imageView, final boolean isClicked) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Story").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int i = 0;
                long timestamp = System.currentTimeMillis();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    TheAtmosphereStory story = snap.getValue(TheAtmosphereStory.class);
                    if (timestamp > story.getTimeStart() && timestamp < story.getTimeEnd()) {
                        i++;
                    }
                }
                if (isClicked) {
                   if(i>0){
                       AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                       alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "view atmospehere", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialogInterface, int i) {
                               //TODO GO TO STORY
                           }
                       });
                       alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Add atmospehere", new DialogInterface.OnClickListener() {
                               @Override
                               public void onClick(DialogInterface dialogInterface, int i) {
                                   Intent intent = new Intent(context, AddStory.class);
                                   context.startActivity(intent);
                                   dialogInterface.dismiss();
                               }
                           });
                       alertDialog.show();
                   } else {
                       Intent intent = new Intent(context, AddStory.class);
                       context.startActivity(intent);
                   }

                } else {
                    if (i > 0) {
                        textView.setText("Venue Story");
                        imageView.setVisibility(View.GONE);
                    } else {
                        textView.setText("Add Story");
                        imageView.setVisibility(View.VISIBLE);
                    }
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
        private void venueStorySeen(ViewHolder vie,String userID){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Story")
                .child(userID);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int i = 0;
                for (DataSnapshot ds : snapshot.getChildren()) {
                    if (!ds.child("views").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).exists() && System.currentTimeMillis() < ds.getValue(TheAtmosphereStory.class).getTimeEnd()) {
                        i++;
                    }
                }

                if (i > 0) {
                    vie.photo_story.setVisibility(View.VISIBLE);
                    vie.story_seen.setVisibility(View.GONE);
                } else {
                    vie.photo_story.setVisibility(View.GONE);
                    vie.story_seen.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        }
    }





