package com.application.atmosphereApp.Adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.application.atmosphereApp.Fragments.PostsDetails;
import com.application.atmosphereApp.Models.Notifications;
import com.application.atmosphereApp.Models.Posts;
import com.application.atmosphereApp.Models.Users;
import com.application.atmosphereApp.R;
import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.ViewHolder>{


    private Context context;
    private List<Notifications>  notificationsM;


    public NotificationsAdapter(){

    }
    public NotificationsAdapter(Context context, List<Notifications> notificationsM){
        this.context = context;
        this.notificationsM = notificationsM;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
       View v = LayoutInflater.from(context).inflate(R.layout.notification_items,parent,false);

       return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Notifications notification = notificationsM.get(position);

        holder.text.setText(notification.getText());

        getUserData(holder.profile_img, holder.name,notification.getUserID());

        if(notification.isPosted()){
            holder.post_img.setVisibility(View.VISIBLE);
            getPostedImage(holder.post_img, notification.getPostID());
        } else {
            holder.post_img.setVisibility(View.GONE);
        }
        holder.itemView.setOnClickListener(view -> {
           if (notification.isPosted()){
                SharedPreferences.Editor editor = context.getSharedPreferences("Preferences", Context.MODE_PRIVATE).edit();
                editor.putString("postID", notification.getPostID());
                editor.apply();

                ((FragmentActivity)context).getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment, new PostsDetails()).commit();

            } else {
                SharedPreferences.Editor editor = context.getSharedPreferences("Preferences",Context.MODE_PRIVATE).edit();
                editor.putString("profileID", notification.getUserID());
                editor.apply();
                return;




            }
        });
    }

    @Override
    public int getItemCount() {
        return notificationsM.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView profile_img, post_img;
        public TextView name, text;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            profile_img = itemView.findViewById(R.id.profile_img);
            post_img = itemView.findViewById(R.id.post_img);
            name = itemView.findViewById(R.id.venueName);
            text = itemView.findViewById(R.id.notifications_comment);
        }
    }

    private void getUserData(ImageView imgV, TextView name, String postedBy ){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child(postedBy);
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Users user = snapshot.getValue(Users.class);
                    Glide.with(context).load(user.getImageURL()).into(imgV);

                    name.setText(user.getUserName());

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


    }
    private void getPostedImage(ImageView imageView, String postID){
        DatabaseReference ref2 = FirebaseDatabase.getInstance().getReference("Posts").child(postID);
        ref2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Posts posts = snapshot.getValue(Posts.class);
                Glide.with(context).load((posts.getPostImage())).into(imageView);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

}
