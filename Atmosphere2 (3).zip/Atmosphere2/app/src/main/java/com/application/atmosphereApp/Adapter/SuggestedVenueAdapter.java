package com.application.atmosphereApp.Adapter;

public class SuggestedVenueAdapter {
}
