package com.application.atmosphereApp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.application.atmosphereApp.Models.Venues;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;


//add try catches
public class EditProfile extends AppCompatActivity {

    ImageView exit, profile_img;
    TextView save, change_pic;
    EditText addressVenue, name;

    FirebaseUser firebaseU;
    private Uri imageURL;
    private StorageTask upload;
    StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);


        //connect java to xml

        addressVenue = findViewById(R.id.venueAddress);

        name = findViewById(R.id.name);
        exit = findViewById(R.id.exit);
        save = findViewById(R.id.save);
        profile_img = findViewById(R.id.profile_img);
        change_pic = findViewById(R.id.change_pic);





        firebaseU = FirebaseAuth.getInstance().getCurrentUser();
        storageReference = FirebaseStorage.getInstance().getReference("uploads");

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Venues").child(firebaseU.getUid());
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Venues venue = snapshot.getValue(Venues.class);
                name.setText(venue.getVenueName());
                addressVenue.setText(venue.getEmailAdd());
                Glide.with(getApplicationContext()).load(venue.getImageURL()).into(profile_img);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                finish();
            }
        });

        change_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CropImage.activity().setAspectRatio(1, 1)
                        .setCropShape(CropImageView.CropShape.OVAL)
                        .start(EditProfile.this);

            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                getGeoLocationVenueWithAddress(getApplicationContext() ,addressVenue.toString());
                updateProfile(name.toString(),
                        addressVenue.toString());
                uploadImage();

            }
        });

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }



    public  void updateProfile(String name, String streetAdd){


        DatabaseReference ref1 = FirebaseDatabase.getInstance().getReference("Venues").child(firebaseU.getUid());

        HashMap<String,Object> map = new HashMap<>();
        map.put("venueName",name);
        map.put("address",streetAdd);

        ref1.updateChildren(map);

        Toast.makeText(EditProfile.this,"Your Profile has been Updated", Toast.LENGTH_SHORT).show();
    }


  private String getExtensionOfFile(Uri uri){
      ContentResolver contentResolver = getContentResolver();
      MimeTypeMap typeMap = MimeTypeMap.getSingleton();
      return  typeMap.getExtensionFromMimeType(contentResolver.getType(uri));
  }
  private void uploadImage(){
     final ProgressDialog pd = new ProgressDialog(this);
      pd.setMessage("uploading");
      pd.show();
      if (imageURL != null){
          StorageReference fileref = storageReference.child(System.currentTimeMillis()+ "." +getExtensionOfFile(imageURL));


          upload = fileref.putFile(imageURL);
          upload.continueWithTask(task -> {
              if (!task.isSuccessful()) {
                  throw task.getException();
              }

              return  fileref.getDownloadUrl();
          }).addOnCompleteListener(new OnCompleteListener<Uri> (){
              @Override
              public void onComplete(@NonNull Task<Uri> task) {
                  if(task.isSuccessful()){
                      Uri download = task.getResult();
                      String uRL = download.toString();

                      DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Venues").child(firebaseU.getUid());
                        HashMap<String, Object> hashMap = new HashMap<>();
                        hashMap.put("imageURL" ,""+uRL);

                        ref.updateChildren(hashMap);
                        pd.dismiss();
                  } else {
                      Toast.makeText(EditProfile.this, "Edit Failed", Toast.LENGTH_SHORT).show();
                  }
              }
          }).addOnFailureListener(new OnFailureListener() {
              @Override
              public void onFailure(@NonNull Exception e) {
                  Toast.makeText(EditProfile.this, e.getMessage(), Toast.LENGTH_SHORT).show();
              }
          });

      } else {
          Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show();
      }
  }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK){

            CropImage.ActivityResult res = CropImage.getActivityResult(data);
            imageURL = res.getUri();

            uploadImage();



        } else {
            Toast.makeText(this, "It has not worked", Toast.LENGTH_SHORT).show();
        }
    }

   // private LatLng getGeoLocationVenueWithAddress(Context context, String addressV){
     //   Geocoder geocoder = new Geocoder(context);
       // LatLng latLng = null;
       // List<Address> addresses;
         //      try{
           // addresses = geocoder.getFromLocationName(String.valueOf(addressV),2);
           // Address location = addresses.get(0);
           // Double lat = location.getLatitude();
           // Double longitude = location.getLongitude();

         ///   latLng = new LatLng(lat, longitude);

            //       DatabaseReference ref1 = FirebaseDatabase.getInstance().getReference("Venues").child(firebaseU.getUid());

              //     HashMap<String,Object> map = new HashMap<>();
                //   map.put("latitude",lat);
                 //  map.put("longitude",longitude);

                //   ref1.setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                  //     @Override
                    //   public void onComplete(@NonNull Task<Void> task) {
                      //     Toast.makeText(EditProfile.this, "location info stored", Toast.LENGTH_SHORT).show();
                       //}
                   //});


           //    } catch (IOException e) {

   //     }   return latLng;



 //   }



}