package com.application.atmosphereApp.Adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;


import com.application.atmosphereApp.Fragments.PostsDetails;
import com.application.atmosphereApp.Models.Posts;
import com.application.atmosphereApp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MyPhotosAdapter extends RecyclerView.Adapter<MyPhotosAdapter.ImageViewHolder> {

    private Context contextM;
    FirebaseUser firebaseUser;
    private List<Posts> postsM;

    public MyPhotosAdapter(Context context, List<Posts> posts){
        contextM = context;
        postsM = posts;
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(contextM).inflate(R.layout.photos_item,parent,false);
        return new MyPhotosAdapter.ImageViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, final int position) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
           Posts currentPosts = postsM.get(position);

        Picasso.get().load(currentPosts.getPostImage()).fit().into(holder.image_posted);

            holder.image_posted.setOnClickListener(view -> {
                SharedPreferences.Editor editor = contextM.getSharedPreferences("PREFS",
                        Context.MODE_PRIVATE ).edit();
                editor.putString("postID", currentPosts.getPostID());

                ((FragmentActivity)contextM).getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment, new PostsDetails()).commit();
            });


    }

    @Override
    public int getItemCount() {
        return postsM.size();
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder{

        public ImageView image_posted;

        public ImageViewHolder(View item){
            super(item);

            image_posted = item.findViewById(R.id.post_img_photo);
        }
    }
}
