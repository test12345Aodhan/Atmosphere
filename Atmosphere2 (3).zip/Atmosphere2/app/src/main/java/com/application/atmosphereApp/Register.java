package com.application.atmosphereApp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Register extends AppCompatActivity {

    FirebaseAuth mAuth;
    DatabaseReference ref;
    ProgressDialog progressD;

    EditText venueName, email, password, password_confirm, et_place;
    Button register;
    TextView login_acc_already;
    Spinner tag1, tag2, tag3, tag4, tag5;


    //add try catches
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);
        et_place = findViewById(R.id.et_place);

        final String[] spinner = getResources().getStringArray(R.array.spinnerItemTags);
         tag1 = findViewById(R.id.spinner1);
         tag2 = findViewById(R.id.spinner2);
         tag3 = findViewById(R.id.spinner3);
         tag4 = findViewById(R.id.spinner4);
         tag5 = findViewById(R.id.spinner5);


        password_confirm = findViewById(R.id.passwordConfirm);
        register = findViewById(R.id.registerBTN);
        venueName = findViewById(R.id.venueName);
        email = findViewById(R.id.emailAddress);
        password = findViewById(R.id.password);
        login_acc_already = findViewById(R.id.login_acc_already);
        ArrayAdapter<String> array = new ArrayAdapter<String>(Register.this, R.layout.support_simple_spinner_dropdown_item, spinner);


        tag1.setAdapter(array);
        tag2.setAdapter(array);
        tag3.setAdapter(array);
        tag4.setAdapter(array);
        tag5.setAdapter(array);





        mAuth = FirebaseAuth.getInstance();

        login_acc_already.setOnClickListener(view -> startActivity(new Intent(Register.this, Login.class)));
        register.setOnClickListener(view -> {
            progressD = new ProgressDialog(Register.this);
            progressD.setMessage("Please wait");
            progressD.show();


            String reg_tag1 = tag1.getSelectedItem().toString();
            String reg_tag2 = tag2.getSelectedItem().toString();
            String reg_tag3 = tag3.getSelectedItem().toString();
            String reg_tag4 = tag4.getSelectedItem().toString();
            String reg_tag5 = tag5.getSelectedItem().toString();



            String venueName_reg = venueName.getText().toString();
            String email_reg = email.getText().toString();
            String password_reg = password.getText().toString();
            String password_dup_reg = password_confirm.getText().toString();




            if (TextUtils.isEmpty(venueName_reg)
                    || TextUtils.isEmpty(email_reg) || TextUtils.isEmpty(password_reg) || TextUtils.isEmpty(password_dup_reg)) {
                Toast.makeText(Register.this, "All fields required", Toast.LENGTH_SHORT).show();
            } else if (!password_dup_reg.matches(password_reg)) {
                password_confirm.setError("password does not match");
                password_confirm.requestFocus();
                return;
            } else if (password_reg.length() < 6) {
                password.setError("password length at least 6 characters, try again");
                password.requestFocus();
                return;

            } else {
                registerVenue(venueName_reg, password_reg, email_reg, reg_tag1, reg_tag2, reg_tag3, reg_tag4, reg_tag5);
            }
        });
    }


    private void registerVenue(final String venueName, String password, String email, String tag1, String tag2, String tag3, String tag4, String tag5){
        try {

            //progressd

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {

                        FirebaseUser firebaseUser = mAuth.getCurrentUser();

                        String venueID = firebaseUser.getUid();

                        ref = FirebaseDatabase.getInstance().getReference().child("Venues").child(venueID);


                        HashMap<String, Object> hashMap = new HashMap<>();
                        hashMap.put("id",venueID);
                        hashMap.put("venueName",venueName);
                        hashMap.put("emailAdd", email);
                        hashMap.put("imageURL", "default");
                        hashMap.put("tag1", tag1);
                        hashMap.put("tag2",tag2);
                        hashMap.put("tag3", tag3);
                        hashMap.put("tag4", tag4);
                        hashMap.put("tag5", tag5);

                        ref.setValue(hashMap).addOnCompleteListener(task1 -> {
                            if (task1.isSuccessful()){
                                progressD.dismiss();
                                Toast.makeText(Register.this, "Venue Registered, Go to profile and Edit to complete", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(Register.this,Login.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);

                            }
                        });

                    }
                });
        }catch(Exception e) {
            progressD.dismiss();
            Toast.makeText(Register.this, "Something went wrong there", Toast.LENGTH_SHORT).show();
        }

    }









}






