package com.application.atmosphereApp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.application.atmosphereApp.CustomerSide.LoginCustomer;
import com.application.atmosphereApp.CustomerSide.RegisterAsCustomer;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class StartActivity extends AppCompatActivity {


    //variables
    AppCompatButton login, register, registerCustomer, loginCustomer;

    FirebaseUser user_firebase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);


        //connect xml to java
        loginCustomer = findViewById(R.id.loginBtnCust);
        login = findViewById(R.id.loginBtn);
        register = findViewById(R.id.registerBTN);
        registerCustomer = findViewById(R.id.register_customer);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(StartActivity.this, Login.class));
            }
        });

        loginCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(StartActivity.this, LoginCustomer.class));
            }
        });


        registerCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(StartActivity.this, RegisterAsCustomer.class));
            }
        });

        //when register is clicked
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(StartActivity.this, Register.class));
            }
        });
    }


//add in exceptions and try catches to all

    @Override
    protected void onStart(){
        super.onStart();
        user_firebase = FirebaseAuth.getInstance().getCurrentUser();

        //if user is not null then direct to...
        if (user_firebase != null){
            startActivity(new Intent(StartActivity.this, MainActivity.class));
            finish();
        }
    }

}