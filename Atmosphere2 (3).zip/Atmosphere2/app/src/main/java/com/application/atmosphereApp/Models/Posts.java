package com.application.atmosphereApp.Models;


import com.google.firebase.database.FirebaseDatabase;

public class Posts {
//class vars
    private String postImage;
    private String postID;
    private String postDescription;
    private String postedBy;

public Posts(){

}

//constructor with params
    public Posts(String postID, String postImage, String postedBy, String postDescription){
        this.postID = postID;
        this.postImage = postImage;
        this.postedBy = postedBy;
        this.postDescription = postDescription;
    }
//getters and setters
    public String getPostImage() {
        return postImage;
    }

    public void setPostImage(String postImage) {
        this.postImage = postImage;
    }

    public String getPostID() {
        return postID;
    }

    public void setPostID(String postImage) {
        this.postID = postImage;
    }

    public String getPostDescription() {
        return postDescription;
    }

    public void setPostDescription(String postDescription) {
        this.postDescription = postDescription;
    }

    public String getPostedBy() {
        return postedBy;
    }

    public void setPostedBy(String postedBy) {
        this.postedBy = postedBy;
    }


}
