package com.application.atmosphereApp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * class to allow customer to login, as either a Venue or User
 */
public class Login extends AppCompatActivity {

    //class vars for java to xml connection
    TextView sign_up;
    EditText password, email;
    AppCompatButton login;

    //connect to firebase var
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //connect xml to java

        sign_up = findViewById(R.id.signUp);
        login = findViewById(R.id.loginBtn);
        password = findViewById(R.id.password);
        email= findViewById(R.id.emailAddress);




        mAuth = FirebaseAuth.getInstance();


        //set link through signup to take to reg page
    sign_up.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View view) {
            //if sign_up is clicked then redirects to register class
            startActivity(new Intent(Login.this, Register.class));

        }
    });

        login.setOnClickListener(view -> {
            //if login button is clicked then show dialog bar
            ProgressDialog progressD = new ProgressDialog(Login.this);
            progressD.setMessage("Wait please");
            progressD.show();
            //convert user text input to string
            String email_log = email.getText().toString();
            String password_log = password.getText().toString();

            //if nothing entered on password on email then focus on boxes and display message
            if (TextUtils.isEmpty(email_log) || TextUtils.isEmpty(password_log)){
                email.requestFocus();
                password.requestFocus();
                Toast.makeText(Login.this, "All Fields Required", Toast.LENGTH_SHORT).show();

            } else{

                //check if email and password
                mAuth.signInWithEmailAndPassword(email_log,password_log)
                        .addOnCompleteListener(Login.this, task -> {
                            //if filled in then check against registered details
                            if (task.isSuccessful()) {
                                //references to for connection to database under Venues and Users table
                                DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Venues").child(mAuth.getCurrentUser().getUid());
                                ref.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        progressD.dismiss();
                                        Intent intent = new Intent(Login.this, MainActivity.class);

                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                                        startActivity(intent);
                                        finish();

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                        //if user cancels login then dismiss dialog bar
                                        progressD.dismiss();
                                    }
                                });

                            } else {
                                progressD.dismiss();
                                Toast.makeText(Login.this, "Login Failed", Toast.LENGTH_SHORT).show();
                            }

                        });
            }

        });


    }
}