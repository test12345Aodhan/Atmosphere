package com.application.atmosphereApp.Models;


public class Venues {



    private String id;
    private String venueName;
    private String imageURL;
    private String emailAdd;

    private String tag1;
    private String tag2;
    private String tag3;
    private String tag4;
    private String tag5;


public Venues(){

}
    public Venues(String id, String venueName, String imageURL, String emailAdd, String tag1, String tag2, String tag3, String tag4, String tag5) {
        this.id = id;
        this.venueName = venueName;
        this.imageURL = imageURL;
        this.emailAdd = emailAdd;
        this.tag1 = tag1;
        this.tag2 = tag2;
        this.tag3 = tag3;
        this.tag4 = tag4;
        this.tag5 = tag5;
    }

    /**
     * @return the imageURL
     */
    public String getImageURL() {
        return imageURL;
    }
    /**
     * @param imageURL the imageURL to set
     */
    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    /**
     * @return the venueName
     */
    public String getVenueName() {
        return venueName;
    }
    /**
     * @param venueName the venueName to set
     */
    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }
    /**
     * @return the id
     */
    public String getId() {
        return id;
    }
    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }



    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getTag3() {
        return tag3;
    }

    public void setTag3(String tag3) {
        this.tag3 = tag3;
    }

    public String getTag4() {
        return tag4;
    }

    public void setTag4(String tag4) {
        this.tag4 = tag4;
    }

    public String getTag5() {
        return tag5;
    }

    public void setTag5(String tag5) {
        this.tag5 = tag5;
    }

    public String getEmailAdd() {
        return emailAdd;
    }

    public void setEmailAdd(String emailAdd) {
        this.emailAdd = emailAdd;
    }
}
