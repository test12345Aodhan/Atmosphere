package com.application.atmosphereApp.Adapter;

import android.content.Context;
import android.content.Intent;

import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.application.atmosphereApp.Fragments.Profile;
import com.application.atmosphereApp.MainActivity;
import com.application.atmosphereApp.Models.Venues;
import com.application.atmosphereApp.R;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;


import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public  class VenueAdapter extends RecyclerView.Adapter<VenueAdapter.ViewHolder> {

    private Context context;
    private List<Venues> mVenues;
    private boolean isFrag;

    //connect to firebase var
    private FirebaseUser firebaseUser;

    public VenueAdapter(){

    }


    public VenueAdapter(Context context,List<Venues>mVenues,boolean isFrag){
        this.context = context;
        this.mVenues = mVenues;
        this.isFrag = isFrag;
    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup vGroup, int viewType) {
       View view;
        view = LayoutInflater.from(context).inflate(R.layout.venue_item,vGroup, false);
        return new VenueAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();


        final Venues venue = mVenues.get(i);

        holder.follow_btn.setVisibility(View.VISIBLE);
        isFollowing(venue.getId(),holder.follow_btn);
        holder.venueName.setText(venue.getVenueName());
        holder.tag1.setText(venue.getTag1());
        holder.tag2.setText(venue.getTag2());
        holder.tag3.setText(venue.getTag3());
        holder.tag4.setText(venue.getTag4());
        holder.tag5.setText(venue.getTag5());
        Picasso.get().load(venue.getImageURL()).placeholder(R.mipmap.ic_launcher).into(holder.profile_img);




        if (venue.getId().equals(firebaseUser.getUid())){
            holder.follow_btn.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isFrag) {
           SharedPreferences.Editor editor = context.getSharedPreferences("PREFS",Context.MODE_PRIVATE).edit();

           editor.putString("profileID", venue.getId());
           ((FragmentActivity) context).getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment,
                            new Profile()).commit();
                } else {
                    Intent intent = new Intent(context, MainActivity.class);
                    intent.putExtra("postedBy", venue.getId());
                    context.startActivity(intent);
                }
            }
        });
        holder.follow_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.follow_btn.getText().toString().equals("follow")){
                    FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                            .child("following").child(venue.getId()).setValue(true);
                    FirebaseDatabase.getInstance().getReference().child("Follow").child(venue.getId())
                            .child("followers").child(firebaseUser.getUid()).setValue(true);

                        addNotification(venue.getId());
                } else {
                    FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                            .child("following").child(venue.getId()).removeValue();
                    FirebaseDatabase.getInstance().getReference().child("Follow").child(venue.getId())
                            .child("followers").child(firebaseUser.getUid()).removeValue();

                }

            }
        });
    }

    @Override
    public int getItemCount() {

        return mVenues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView venueName, tag1, tag2, tag3, tag4, tag5, venueLocation;
        public CircleImageView profile_img;
        public AppCompatButton follow_btn;

        public ViewHolder(@NonNull View itemView){

            super(itemView);
//connect java to xml
            venueName = itemView.findViewById(R.id.venueName);
            follow_btn = itemView.findViewById(R.id.follow_btn);
            profile_img = itemView.findViewById(R.id.profile_img);
            tag1 = itemView.findViewById(R.id.venue_Tags);
            tag2 = itemView.findViewById(R.id.venue_Tags2);
            tag3 = itemView.findViewById(R.id.venue_Tags3);
            tag4 = itemView.findViewById(R.id.venue_Tags4);
            tag5 = itemView.findViewById(R.id.venue_Tags5);
//add in bar tags

        }


    }

    private void isFollowing(String venueID, Button btn){

        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid()
        ).child("following");


        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.child(venueID).exists()){
                    btn.setText("following");
                } else {
                    btn.setText("follow");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void addNotification(String venueID){
        HashMap<String, Object> hashmap = new HashMap<>();
        hashmap.put("venueID", venueID);
        hashmap.put("text", "started Following You");
        hashmap.put("postID", "");
        hashmap.put("isPost", false);

        FirebaseDatabase.getInstance().getReference().child("Notifications").child(firebaseUser.getUid()).push().setValue(hashmap);
    }


}
