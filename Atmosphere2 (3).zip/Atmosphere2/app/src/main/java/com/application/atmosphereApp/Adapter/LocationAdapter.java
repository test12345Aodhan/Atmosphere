package com.application.atmosphereApp.Adapter;

public class LocationAdapter {
}
