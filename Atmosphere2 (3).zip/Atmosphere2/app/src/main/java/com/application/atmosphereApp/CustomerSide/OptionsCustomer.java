package com.application.atmosphereApp.CustomerSide;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.application.atmosphereApp.R;
import com.application.atmosphereApp.StartActivity;
import com.google.firebase.auth.FirebaseAuth;

public class OptionsCustomer extends AppCompatActivity {


    TextView settings, log_out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options_customer);
        Toolbar toolbar= findViewById(R.id.tool_bar);
        log_out = findViewById(R.id.log_Out);
        settings = findViewById(R.id.settings);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Options");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        log_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(OptionsCustomer.this, StartActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));

            }
        });


    }


}
